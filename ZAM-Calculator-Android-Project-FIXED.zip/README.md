# ZAM Calculator — Android

Native Android version of the ZAM calculator. Supports addition, subtraction, multiplication, division, decimals, sign change, clear, and backspace.

## Build with GitHub Actions

1. Upload the contents of this folder into your repository under:
   `zam_project_20261112_201015_android`
2. Open **Actions** → **ZAM AI Android APK Builder** → **Run workflow**.
3. Set `project_dir` to `zam_project_20261112_201015_android`.
4. Run the workflow and wait for it to finish.
5. Open the successful run and download the **ZAM-AI-Android-APK** artifact.
6. Extract the artifact ZIP and install the APK on your Android phone.

The workflow runner supplies Java 17, Android SDK 35, and Gradle 8.10.2.
