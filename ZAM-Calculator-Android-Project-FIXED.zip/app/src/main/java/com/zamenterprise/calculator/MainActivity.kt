package com.zamenterprise.calculator

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.math.BigDecimal
import java.math.MathContext

class MainActivity : Activity() {
    private lateinit var display: TextView
    private var current = "0"
    private var stored: Double? = null
    private var pending: String? = null
    private var startNewNumber = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        updateDisplay()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 24, 18, 18)
            setBackgroundColor(0xFFF4F6FA.toInt())
        }
        val heading = TextView(this).apply {
            text = "ZAM CALCULATOR"
            textSize = 18f
            setTextColor(0xFF526078.toInt())
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        root.addView(heading, LinearLayout.LayoutParams(-1, 56))
        display = TextView(this).apply {
            textSize = 42f
            setTextColor(0xFF17243A.toInt())
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
            setPadding(12, 12, 12, 12)
            setBackgroundColor(0xFFFFFFFF.toInt())
            maxLines = 1
        }
        root.addView(display, LinearLayout.LayoutParams(-1, 0, 1f).apply {
            setMargins(0, 12, 0, 20)
        })
        val rows = listOf(
            listOf("C", "⌫", "÷", "×"),
            listOf("7", "8", "9", "−"),
            listOf("4", "5", "6", "+"),
            listOf("1", "2", "3", "="),
            listOf("±", "0", ".", "=")
        )
        rows.forEachIndexed { rowIndex, row ->
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.forEachIndexed { colIndex, label ->
                val button = Button(this).apply {
                    text = label
                    textSize = 21f
                    isAllCaps = false
                    val operator = label in listOf("+", "−", "×", "÷", "=")
                    setTextColor(if (operator) 0xFFFFFFFF.toInt() else 0xFF17243A.toInt())
                    backgroundTintList = android.content.res.ColorStateList.valueOf(
                        if (operator) 0xFF315EFB.toInt()
                        else if (label == "C") 0xFFFFE7E7.toInt()
                        else 0xFFFFFFFF.toInt()
                    )
                    setOnClickListener { onKey(label) }
                }
                if (rowIndex == 4 && colIndex == 3) button.visibility = android.view.View.INVISIBLE
                line.addView(button, LinearLayout.LayoutParams(0, 68, 1f).apply {
                    setMargins(4, 4, 4, 4)
                })
            }
            root.addView(line)
        }
        setContentView(root)
    }

    private fun onKey(key: String) {
        when (key) {
            "C" -> clearAll()
            "⌫" -> if (!startNewNumber) current = if (current.length > 1) current.dropLast(1) else "0"
            "+", "−", "×", "÷" -> chooseOperator(key)
            "=" -> calculate()
            "±" -> if (current != "0") current = if (current.startsWith("-")) current.drop(1) else "-$current"
            "." -> if (!startNewNumber && !current.contains(".")) current += "."
            else -> {
                if (startNewNumber || current == "0") current = key
                else if (current.length < 14) current += key
                startNewNumber = false
            }
        }
        updateDisplay()
    }

    private fun chooseOperator(op: String) {
        if (pending != null && !startNewNumber) calculate()
        stored = current.toDoubleOrNull()
        pending = op
        startNewNumber = true
    }

    private fun calculate() {
        val left = stored ?: return
        val right = current.toDoubleOrNull() ?: return
        val result = when (pending) {
            "+" -> left + right
            "−" -> left - right
            "×" -> left * right
            "÷" -> {
                if (right == 0.0) {
                    Toast.makeText(this, "Cannot divide by zero", Toast.LENGTH_SHORT).show()
                    return
                }
                left / right
            }
            else -> return
        }
        current = format(result)
        stored = null
        pending = null
        startNewNumber = true
    }

    private fun format(value: Double): String {
        if (!value.isFinite()) return "Error"
        return BigDecimal(value.toString()).round(MathContext(12)).stripTrailingZeros().toPlainString()
    }

    private fun clearAll() {
        current = "0"
        stored = null
        pending = null
        startNewNumber = false
    }

    private fun updateDisplay() { display.text = current }
}
